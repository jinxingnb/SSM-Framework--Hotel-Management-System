package com.ischoolbar.programmer.entity;

import java.util.Date;

import org.springframework.stereotype.Component;

/**
 * Ԥ������ʵ����
 * @author Administrator
 *
 */
@Component
public class BookOrder {
	private Long id;//Ԥ������id
	private Long accountId;//�ͻ�id
	private Long roomTypeId;//����id
	private String name;//Ԥ��������
	private String idCard;//����֤����
	private String mobile;//�ֻ���
	private int status;//״̬��0��Ԥ���У�1������ס,2:�ѽ������
	private String arriveDate;//��ס����
	private String leaveDate;//�������
	private Date createTime;//Ԥ������
	private String remark;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public Long getAccountId() {
		return accountId;
	}
	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}
	public Long getRoomTypeId() {
		return roomTypeId;
	}
	public void setRoomTypeId(Long roomTypeId) {
		this.roomTypeId = roomTypeId;
	}
	public String getIdCard() {
		return idCard;
	}
	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getArriveDate() {
		return arriveDate;
	}
	public void setArriveDate(String arriveDate) {
		this.arriveDate = arriveDate;
	}
	public String getLeaveDate() {
		return leaveDate;
	}
	public void setLeaveDate(String leaveDate) {
		this.leaveDate = leaveDate;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	
	
}
